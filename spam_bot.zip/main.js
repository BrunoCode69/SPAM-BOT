const qrcode = require('qrcode-terminal');
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const puppeteer = require("puppeteer");
const firebase = require("firebase");
const FireSimple = require("./firebase.js");
const config = require("./config.json");
const { ClientRequest } = require('http');
const ms = require("pixapi");
const donos = ['5527997809769','5513996194609'];
const client = new Client({
  authStrategy: new LocalAuth({ clientId: 'WhatsappBot', dataPath: 'chorme' }),
  takeoverOnConflict: true,
  puppeteer: { args: ['--disable-dev-shm-usage', '--no-sandbox', '--disable-setuid-sandbox'] }
});

const db = new FireSimple({
  apiKey: "AIzaSyDfMCKFzku7KOkWh6c2Hezvz_zytigwvjA",
  databaseURL: "https://spam-bot-whatsapp-default-rtdb.firebaseio.com",
});

client.on('qr', qr => {
  qrcode.generate(qr, { small: true });
});

client.on('ready', function () {
  const segs = [10, 11, 12, 13, 14, 15]

  setInterval(async function () {
    let limite = await db.get(`envio/${config.contact}`);
    let message_enviada = await db.get(`envio/${config.contact}`);
    const perfil = await db.get(`envio/${config.contact}/status`);
    if(!perfil) return;
    if(!limite) return;
    if(message_enviada.messages_sended == limite.limite || message_enviada.messages_sended > limite.limite) {
      db.set(`envio/${config.contact}`, {
        status: 0
      });
      return;
    }
   
    if (perfil == 1) {
      const random = ms.randomNumber(10000000, 8000000)
      const numero_gerado = `+55${config.ddd}99${random}`
      const numero_final = numero_gerado.substring(1) + "@c.us";
      try {
        client.sendMessage(numero_final, config.message_divugation);
        db.set(`envio/${config.contact}`, {
          messages_sended: message_enviada.messages_sended + 1
        });
      } catch (error) {
        console.log("Não foi possivel enviar mensagem ao numero: " + numero_gerado);
      }
    } else {
      return;
    }
  }, 1000 * segs[Math.floor(Math.random() * segs.length)]);
  console.log('SPAM-BOT INICIADO COM SUCESSO !');
});

client.on("message", async function (message) {
  const user = await message.getContact();
  const number = `+${user.id.user}`;
  const chatID = number.substring(1) + "@c.us";
  const menu_get = await db.get(`menu/${config.contact}/${user.id.user}`);
  let args = message.body.slice("!").trim().split(/ +/g);

  if(args[0].toLowerCase() == "set-limite" && donos.includes(user.id.user)) {
    if(isNaN(args[1])) {
      client.sendMessage(chatID, `❌ Não posso adicionar letras como limite.`);
    } else {
      client.sendMessage(chatID, `✅ Foram adicionadas *${args[1]}* mensagens de limite na conta atual.`);
      db.set(`envio/${config.contact}`, {
        limite: parseInt(args[1]),
        messages_sended: 0
      });
    }
  }

  if (message.body.toLowerCase() == "menu" && user.id.user == config.contact) {
    let envio_status_message = await db.get(`envio/${config.contact}/status`);
    let msg_envio;

    if(!envio_status_message || envio_status_message != 1) {
      msg_envio = "🔴 Desligado"
    } else {
      msg_envio = "🟢 Ligado"
    }

    let limite = await db.get(`envio/${config.contact}/limite`);
    let message_enviada = await db.get(`envio/${config.contact}`);

    if(!message_enviada.messages_sended) await message_enviada.messages_sended === 0;
    if(!limite) await limite === 0;

    let message_menu = `*====== BEM VINDOª AO SPAM-BOT======*\n\n`
    message_menu += `*1* Iniciar o envio de mensagem\n`
    message_menu += `*2* Parar o envio de mensagem\n\n`
    message_menu += `Status do envio: *${msg_envio}*\n`
    message_menu += `Limite de envio: *${message_enviada.messages_sended}/${limite}*\n`
    message_menu += `\nDigite a opção desejada: `
    await client.sendMessage(chatID, message_menu);
    await db.set(`menu/${config.contact}/${user.id.user}`, { menu: 1 });
    return;
  }

  if (message.body == "1" && menu_get != null && menu_get.menu == 1) {
    let status_envio = await db.get(`envio/${config.contact}/status`);
    if (status_envio == 1) {
      client.sendMessage(chatID, "❌ O envio ja esta em execução.");
      db.delete(`menu/${config.contact}/${user.id.user}`);
      return;
    } else {
      let limite = await db.get(`envio/${config.contact}`);
      let message_enviada = await db.get(`envio/${config.contact}`);
      if(!limite) {
        client.sendMessage(chatID, `❌ Você não possui limite disponivel.`);
        db.delete(`menu/${config.contact}/${user.id.user}`);
        return;
      }
      if(message_enviada.messages_sended >= limite.limite) {
        client.sendMessage(chatID, `❌ Seu limite de mensagens acabou.`);
        db.delete(`menu/${config.contact}/${user.id.user}`);
        return;
      }
      client.sendMessage(chatID, "*✅ Envio iniciado com sucesso !*");
      db.set(`envio/${config.contact}`, { status: 1 });
      db.delete(`menu/${config.contact}/${user.id.user}`)
    }
  } else if (message.body == "2" && menu_get != null && menu_get.menu == 1) {
    let status_envio = await db.get(`envio/${config.contact}/status`);
    if (status_envio != null && status_envio == 1) {
      client.sendMessage(chatID, "*✅ Envio parado com sucesso !*");
      db.set(`envio/${config.contact}`, { status: 0 });
      db.delete(`menu/${config.contact}/${user.id.user}`);
    } else {
      client.sendMessage(chatID, "❌ O envio ja esta parado.");
      db.delete(`menu/${config.contact}/${user.id.user}`)
    }
  } else if (menu_get != null && menu_get.menu == 1) {
    client.sendMessage(chatID, "❌ Opção invalida. digite *menu* para ver as opções disponiveis.");
    db.delete(`menu/${config.contact}/${user.id.user}`);
  }
});

client.initialize();